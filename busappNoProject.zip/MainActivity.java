package com.example.owner.busapp;


import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements Subscriber,Serializable {


    public transient Socket requestSocket;
    private transient ObjectOutputStream out = null;
    private transient ObjectInputStream in = null;
    //Info<Topic> topic = new Info<>();
    Intent i;
    private ArrayList<String> topics = new ArrayList<>();

    public Socket getRequestSocket() {
        return requestSocket;
    }

    public ObjectInputStream getIn() {
        return in;
    }

    public ObjectOutputStream getOut() {
        return out;
    }

    public MainActivity() {

    }

    public MainActivity(Socket requestSocket, ObjectInputStream in, ObjectOutputStream out) {

        this.requestSocket = requestSocket;
        this.in = in;
        this.out = out;



    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        try{
            InputStream is = getApplicationContext().getAssets().open("busLinesNew.txt");
            BufferedReader br1 = new BufferedReader(new InputStreamReader(is));


            StringBuilder text = new StringBuilder();
            String line;
            String[] myLine;


            while ((line = br1.readLine()) != null) {
                text.append("\n");
                myLine = line.split(",");
                topics.add(myLine[1]);

            }
            br1.close();


        }catch (IOException e) {
            e.printStackTrace();
        }


        final Spinner dropdown = findViewById(R.id.spinnerId);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, topics);
        dropdown.setAdapter(adapter);
        dropdown.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
//                if(adapterView.getItemAtPosition(i).equals("021")) {
//                    Toast.makeText(getApplicationContext(),"You chose: " + adapterView.getItemAtPosition(i),Toast.LENGTH_SHORT).show();
//                }
                Toast.makeText(getApplicationContext(),"You chose: " + adapterView.getItemAtPosition(i),Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        final Button connect = (Button) findViewById(R.id.button3);
        connect.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                AsyncTaskConnect atc = new AsyncTaskConnect();
                atc.execute();
                connect.setEnabled(false);

            }

        });

        Button input = (Button) findViewById(R.id.buttonId);

        input.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                MainActivity m = new MainActivity(requestSocket,in,out);
                Intent i = new Intent(getApplicationContext(),MapsActivity.class);
                i.putExtra("BusLineId",dropdown.getSelectedItem().toString());
                i.putExtra("constructor",m);
                startActivity(i);


                /*
                AsyncTaskRunner runner = new AsyncTaskRunner();
                //Toast.makeText(getApplicationContext(),dropdown.getSelectedItem().toString(),Toast.LENGTH_SHORT).show();

                MainActivity m = new MainActivity(requestSocket,in,out);

                i = new Intent(getApplicationContext(),MapsActivity.class);
                i.putExtra("constructor",m);
                i.putExtra("busLine",dropdown.getSelectedItem().toString());
                runner.execute(dropdown.getSelectedItem().toString());
                */

            }
        });



    }

    private class AsyncTaskConnect extends AsyncTask<Void, Void, Void> {


        @Override
        protected Void doInBackground(Void... voids) {
            connect();
            return null;
        }
    }

    /*
    private class AsyncTaskRunner extends AsyncTask<String, Tuple<Value>, Tuple<Value>> {

        private ProgressDialog dialog;

        @Override
        protected Tuple<Value> doInBackground(String... params) {
            Log.e("msg","Result is: doIn Background");

            Log.e("msg","Result is: after doInBackground");
            Log.e("msg","Result is: " + params[0]);

            Tuple<Value> t = ask(params[0]);
            //onProgressUpdate(t);
            return t;

        }

        @Override
        protected void onPostExecute(Tuple<Value> result) {
            if (dialog.isShowing()) {
                dialog.dismiss();
            }
            Log.e("msg","Result is: on Post Execute Vehicle " + result.get(0).getBus().getVehicleId());
            i.putExtra("Tuple",result);
            startActivity(i);

        }

        @Override
        protected void onPreExecute() {
            Log.e("msg","Result is: on Pre execute");
            dialog = new ProgressDialog(MainActivity.this);
            dialog.setMessage("Please wait...");
            dialog.show();





        }

        @Override
        protected void onProgressUpdate(Tuple<Value>... text) {


        }
    }*/


    @Override
    public void init(int x) {

    }



    @Override
    //Makes the connection with the brokers and the subscriber registers in the right broker.
    public void connect() {
        for (Broker b : brokers) {
            String message;
            try {
                requestSocket = new Socket(InetAddress.getByName(b.getIp()), b.getPort());
                out = new ObjectOutputStream(requestSocket.getOutputStream());
                in = new ObjectInputStream(requestSocket.getInputStream());

                try {
                    Log.e("msg","Subscriber's connect: 1");
                    message = (String) in.readObject(); //message for successful connection
                    int noBrokers = (int) in.readObject(); //number of brokers
                    int id; //broker's id to be updated
                    Info<Topic> topic = new Info<>(); //includes the topics of each broker
                    for (int i = 0; i < noBrokers; i++) {
                        id = (Integer) in.readObject();
                        topic = (Info<Topic>) in.readObject();
                        ArrayList<Topic> top = new ArrayList<Topic>();
                        top = topic;
                        Broker bro = brokers.get(id);
                        bro.setTopics(top);
                        brokers.set(id, bro);

                    }
                    for (Broker br : brokers) {
                        System.out.println(br.getPort() + ": ");
                        for (Topic t : br.getTopics()) {
                            System.out.print(t.getBusLineId());
                            System.out.print(" ");
                        }
                        System.out.println();
                    }
                    Log.e("msg","Subscriber's connect: 2");
                    System.out.println("Broker > " + message);

                } catch (ClassNotFoundException classNot) {
                    System.out.println("Data received in unknown format.");
                }
            } catch (UnknownHostException unknownHost) {
                System.err.println("You are trying to connect to an unknown host!");
            } catch (IOException ioException) {
                ioException.printStackTrace();
            }
        }
    }


    // Gets the information for the requested bus's line id.
    public Tuple<Value> ask(String line) {
        Tuple<Value> finalreply = new Tuple<Value>();
        Log.e("msg","In ask: 1");
        for (Broker b : brokers) {
            try {
                for (Topic t : b.getTopics()) {
                    if (t.getBusLineId().equals(line)) {
                        Log.e("msg","In ask: 2");
                        requestSocket = new Socket(InetAddress.getByName(b.getIp()), b.getPort());
                        out = new ObjectOutputStream(requestSocket.getOutputStream());
                        in = new ObjectInputStream(requestSocket.getInputStream());
                        out.writeObject(line);
                        out.flush();
                        Log.e("msg","In ask: 3");
                        finalreply = (Tuple<Value>) in.readObject(); //finalreply has all the requested information
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
        }
        return finalreply;
    }

    // Disconnects from the broker.
    public void disconnect() { // button "Disconnect"
        for (Broker b : brokers) {
            try {
                Log.e("msg", "In disconnect");
                requestSocket = new Socket(InetAddress.getByName(b.getIp()), b.getPort());
                out = new ObjectOutputStream(requestSocket.getOutputStream());
                in = new ObjectInputStream(requestSocket.getInputStream());

                String msg = "bye";
                out.writeObject(msg);

                in.close();
                out.close();
                requestSocket.close();
            } catch (IOException ioException) {
                ioException.printStackTrace();
            }
        }
    }



}
