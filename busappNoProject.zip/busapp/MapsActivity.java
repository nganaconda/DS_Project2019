package com.example.owner.busapp;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;


import javax.xml.bind.DatatypeConverter;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback,Serializable {

    public MapsActivity() {

    }

    private GoogleMap mMap;
    private ArrayList<Marker> markers = new ArrayList<>();
    private ArrayList<LatLng> latlngs = new ArrayList<>();
    private MarkerOptions markerOptions = new MarkerOptions();
    private String busLine;
    private MainActivity m;
    //private Context mContext;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);


        Bundle b = getIntent().getExtras();
        m = (MainActivity)getIntent().getSerializableExtra("a");
        if(b == null) {
            busLine = null;
            Log.e("Error","busLine var is null");
        }else {
            busLine = b.getString("busLine");
        }
        Toast.makeText(getApplicationContext(),"The busLine you entered is: " + busLine,Toast.LENGTH_SHORT).show();
        Log.e("busLine is",busLine+" ");

    }

    private class AsyncTaskHandler extends AsyncTask<MainActivity, String, String> {

        @Override
        protected String doInBackground(MainActivity... mainActivities) {

            mainActivities[0].disconnect();
            Log.e("msgM", "After implementing doInBackGround");

            return "Yes";
        }

        @Override
        protected void onPostExecute(String result) {


            Log.e("msgM","Result is: on Post Execute " + result);

        }
    }


    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        ArrayList<Value> tuple = (ArrayList<Value>) getIntent().getSerializableExtra("Tuple");



        try {
            InputStream is = getApplicationContext().getAssets().open("RouteCodesNew.txt");
            BufferedReader br1 = new BufferedReader(new InputStreamReader(is));


            StringBuilder text = new StringBuilder();
            String line;
            String[] myLine;
            //Log.e("I am in","In try");
            Log.e("Tuple size",tuple.size()+"");

            while ((line = br1.readLine()) != null) {
                text.append("\n");
                //Log.e("I am in","In while");

                myLine = line.split(",");
                String lineCode = myLine[1];
                String routeCode = myLine[0];

                for(int i=0;i<tuple.size();i++) {
                    //Log.e("I am in","In for");
                    LatLng l = new LatLng(tuple.get(i).getLatitude(),tuple.get(i).getLongitude());
                    latlngs.add(l);
                    markerOptions.position(l);
                    markerOptions.snippet("Time stamp: " + tuple.get(i).getBus().getInfo());


                    if(lineCode.equals(tuple.get(i).getBus().getLineCode()) && routeCode.equals(tuple.get(i).getBus().getRouteCode()) ) {
                        if(myLine[2].equals("1")) {
                            markerOptions.title("Its going to the terminal."); // myLine[3]
                            //markers.add(mMap.addMarker(markerOptions));

                        }else if(myLine[2].equals("2")) {
                            markerOptions.title("Its going towards the start line.");


                        }

                    }
                    Log.e("markers size",markers.size()+" .." + i);
                    //markers.add(mMap.addMarker(markerOptions));

                }
            }
            markers.add(mMap.addMarker(markerOptions));

            Log.e("markers size",markers.size()+"");


        } catch (IOException e) {
            e.printStackTrace();
        }





        //mMap.moveCamera(CameraUpdateFactory.newLatLng(latlngs.get(0)));



//        for(Value v: tuple) {
//
//            LatLng l = new LatLng(v.getLatitude(),v.getLongitude());
//            latlngs.add(l);
//            markerOptions.position(l);
//            markerOptions.title("Bus with vehicle id: " + v.getBus().getVehicleId());
//            markerOptions.snippet("Time stamp: " + v.getBus().getInfo());
//            markers.add(mMap.addMarker(markerOptions));
//        }
//        Log.e("markers size",markers.size()+"");



        int i = 1;
        for (Marker m : markers) {
            m.setTag(i);
            i++;
        }

//        LatLng coordinate= mMap.getCameraPosition().target;
//        CameraUpdate location = CameraUpdateFactory.newLatLngZoom(coordinate, 15);
//        mMap.animateCamera(location);

        mMap.moveCamera(CameraUpdateFactory.newLatLng(latlngs.get(0)));
        mMap.animateCamera(CameraUpdateFactory.zoomTo(12), 2000, null);



        final Button button = findViewById(R.id.button2);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                for (Marker m : markers) {
                    if (m.getTag().equals(1)) {
                        m.setVisible(!m.isVisible());
                    }
                }
                if (markers.get(0).isVisible()) {
                    button.setText("Hide");
                } else {
                    button.setText("Show");
                }
            }
        });

        // Add a marker in Sydney and move the camera
        //LatLng sydney = new LatLng(-34, 151);
        //mMap.addMarker(new MarkerOptions().position(sydney).title("Marker in Sydney"));
        //mMap.moveCamera(CameraUpdateFactory.newLatLng(sydney));


    }



    public void onClick(View view) {
        MainActivity ma = new MainActivity(m.getRequestSocket(),m.getIn(),m.getOut());
        AsyncTaskHandler ath = new AsyncTaskHandler();
        ath.execute(ma);
        Toast.makeText(getApplicationContext(),"You have successfully disconnected.",Toast.LENGTH_SHORT).show();
        startActivity(new Intent(getApplicationContext(),MainActivity.class));
    }
}
