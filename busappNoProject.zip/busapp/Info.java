package com.example.owner.busapp;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;

public class Info<Topic> extends ArrayList<Topic> implements Serializable
{

}
