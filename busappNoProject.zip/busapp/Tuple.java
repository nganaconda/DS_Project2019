package com.example.owner.busapp;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;

public class Tuple<Value> extends ArrayList<Value> implements Serializable {

}
