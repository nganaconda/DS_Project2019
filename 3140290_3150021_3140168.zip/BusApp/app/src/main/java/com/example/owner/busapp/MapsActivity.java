package com.example.owner.busapp;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;


import javax.xml.bind.DatatypeConverter;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Serializable;
import java.util.ArrayList;


public class MapsActivity extends FragmentActivity implements OnMapReadyCallback,Serializable {

    public MapsActivity() {

    }

    private GoogleMap mMap;
    private ArrayList<Marker> markers;
    private ArrayList<LatLng> latlngs;
    private MarkerOptions markerOptions = new MarkerOptions();
    private ArrayList<AsyncTaskRefresher> zombies;
    static Tuple<Value> globalTuple;
    private String busLine;
    private String routeCode;
    private MainActivity m;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);


        Bundle b = getIntent().getExtras();
        m = (MainActivity)getIntent().getSerializableExtra("constructor");
        if(b == null) {
            busLine = null;
            routeCode = null;
            Log.e("Error","busLine var is null");
        }else {
            busLine = b.getString("BusLineId");
            routeCode = b.getString("routeCode");
            Log.e("RouteCode is",routeCode);
        }
        Toast.makeText(getApplicationContext(),"The busLine you entered is: " + busLine,Toast.LENGTH_SHORT).show();
        Log.e("busLine is",busLine+" ");


    }

    private class AsyncTaskRefresher extends AsyncTask<Void, Void, String> {

        private ProgressDialog dialog;
        int waitTime;

        public AsyncTaskRefresher(int waitTime) {
            this.waitTime = waitTime;
        }

        @Override
        protected void onPreExecute() {
            Log.e("msg","onPreExecute....");
            if (waitTime == 0) {
                 dialog = ProgressDialog.show(MapsActivity.this, "Finding buses","Please wait...");
                //dialog.setMessage("Please wait...");
            }

        }

        @Override
        protected String doInBackground(Void... params) {
            try {
                Thread.sleep(waitTime);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            String bus = getIntent().getExtras().getString("BusLineId");
            Tuple<Value> t = m.ask(bus,routeCode);
            globalTuple = t;
            //Log.e("ERROR",globalTuple.get(0).getBus().getInfo());
            Log.e("msg","After executing ask method.");
            return "Showing bus lanes!";


        }

        @Override
        protected void onPostExecute(String text) {

            if(dialog != null) dialog.setMessage(text);
            addBuses();
            if (dialog != null && dialog.isShowing()) {
                dialog.dismiss();
            }

        }



    }


    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;



        final Button button = findViewById(R.id.button2);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                synchronized (markers) {
                    for (Marker m : markers) {
                        if ((int) m.getTag() >= 1) {
                            m.setVisible(!m.isVisible());
                        }
                    }
                    if (markers.get(0).isVisible()) {
                        button.setText("Hide");
                    } else {
                        button.setText("Show");
                    }
                }
            }
        });

        zombies = new ArrayList<AsyncTaskRefresher>();
        for(int i = 0; i < 200; i++) {
            AsyncTaskRefresher atr = new AsyncTaskRefresher(i*1000);
            zombies.add(atr);
            zombies.get(i).execute();
        }
    }

    public void addBuses() {
        try {
            Tuple<Value> tuple = globalTuple;
            Log.e("ERROR",tuple.get(0).getBus().getInfo());
            InputStream is = getApplicationContext().getAssets().open("RouteCodesNew.txt");
            BufferedReader br1 = new BufferedReader(new InputStreamReader(is));
            if(markers != null) {
                synchronized (markers) {
                    for (Marker m : markers) {
                        if ((int)m.getTag()>=1) {
                            m.setVisible(!m.isVisible());
                        }
                    }
                }
            }
            markers = new ArrayList<>();
            latlngs = new ArrayList<>();

            StringBuilder text = new StringBuilder();
            String line;
            String[] myLine;
            Log.e("Tuple size",tuple.size()+"");

            while ((line = br1.readLine()) != null) {
                text.append("\n");
                myLine = line.split(",");
                String lineCode = myLine[1];
                String routeCode = myLine[0];

                for(int i=0;i<tuple.size();i++) {

                    Log.e("On postExecute",tuple.get(i).getBus().getInfo());

                    if(lineCode.equals(tuple.get(i).getBus().getLineCode()) && routeCode.equals(tuple.get(i).getBus().getRouteCode()) ) {
                        if(myLine[2].equals("1")) {
                            LatLng l = new LatLng(tuple.get(i).getLatitude(),tuple.get(i).getLongitude());
                            latlngs.add(l);
                            markerOptions.position(l);
                            markerOptions.snippet("Time stamp: " + tuple.get(i).getBus().getInfo());
                            markerOptions.title("Its going to the terminal. VID: " + tuple.get(i).getBus().getVehicleId());
                            synchronized (markers) {
                                markers.add(mMap.addMarker(markerOptions));
                            }
                        }else if(myLine[2].equals("2")) {
                            LatLng l = new LatLng(tuple.get(i).getLatitude(),tuple.get(i).getLongitude());
                            latlngs.add(l);
                            markerOptions.position(l);
                            markerOptions.snippet("Time stamp: " + tuple.get(i).getBus().getInfo());
                            markerOptions.title("Its going towards the start line. VID: " + tuple.get(i).getBus().getVehicleId());
                            synchronized (markers) {
                                markers.add(mMap.addMarker(markerOptions));
                            }
                        }

                    }
                }
            }
            br1.close();


        } catch (IOException e) {
            e.printStackTrace();
        }

        synchronized (markers) {
            int i = 1;
            for (Marker m : markers) {
                m.setTag(i);
                i++;
            }
        }

        mMap.moveCamera(CameraUpdateFactory.newLatLng(latlngs.get(0)));
        mMap.animateCamera(CameraUpdateFactory.zoomTo(14), 2000, null);


    }

    public void onClick(View view) {
        for(int i = 0; i < zombies.size(); i++) {
            zombies.get(i).cancel(true);
        }
        finish();
    }
}
